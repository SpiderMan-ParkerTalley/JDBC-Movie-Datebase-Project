
public class Movie {
	private int nameLength;
	private int ID;
	
	public Movie(int ID, int nameLength) {
		this.nameLength = nameLength;
		this.ID = ID;
	}

	public int getNameLength() {
		return nameLength;
	}

	public void setNameLength(int nameLength) {
		this.nameLength = nameLength;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	@Override
	public String toString() {
		return "Movie [nameLength=" + nameLength + ", ID=" + ID + "]";
	}

	
	
	
	
}
