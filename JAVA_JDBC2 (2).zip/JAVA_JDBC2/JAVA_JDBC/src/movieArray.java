import java.util.Arrays;

public class movieArray {
	//properties
	//Store integers
	private Movie[] data;
	private int manyItems;
	
	//CONSTRUCTOR
	// Empty constructor
	public movieArray() {
		int initialValue = 10;
		this.data = new Movie[initialValue];
		this.manyItems = 0;
	}
	
	// InitialCapacity constructor 
	public movieArray(int initialValue) {
		this.data = new Movie[initialValue];
		this.manyItems = 0;
	}
	public void addMovie(Movie newMovie) {
		data[manyItems++] = newMovie;
	}
	// Add items
	public void addMovie(int ID, int length) {
		Movie movie = new Movie(ID, length);
		addMovie(movie);
	}
	
	// Remove items
	
	
	// Retrieve items
	public int grabId(int Index) {
		int j = data[Index].getID();
		return j;
	}
	
	public int getLength(int Index) {		
		int k = data[Index].getNameLength();
		return k;
	}
	
	// size 
	public int size() {
		return this.data.length;
	}
	// maximum value

	
	//Compare the number of elements in each bag
	

	// capacity
	public int capacity() {
		return this.manyItems;
	}
	

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		movieArray other = (movieArray) obj;
		if (!Arrays.equals(data, other.data))
			return false;
		if (manyItems != other.manyItems)
			return false;
		return true;
	}
	public String toString() {
		String output = "";
		output += "**************************************";
		for (int i = 0; i < manyItems; i++) {
			output += "\n" + data[i];
		}
		return output;
	}
}
